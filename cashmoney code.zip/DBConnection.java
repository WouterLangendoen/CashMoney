import java.sql.*;

public class DBConnection {
    static final String DB_URL = "jdbc:mysql://145.24.222.63:3306/CashMoney";
    static final String USER = "user";
    static final String PASS = "0000";
    private String result = null;
    private Connection conn;
    private Statement stmt;
    private ResultSet rs;

    public void connect() throws SQLException{
        conn = null;
        stmt = null;
        rs = null;
        try {
            //STEP 2: Register JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            //STEP 3: Open a connection
            System.out.println("Connecting");
            conn = DriverManager.getConnection("jdbc:mysql://145.24.222.63:3306/CashMoney", "sarah", "0000");
            System.out.println("Connection succeeded");

            //STEP 4: Execute a query
            stmt = conn.createStatement();

        }
        catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        }
    }

    public String getData(String query, String column) throws SQLException{
        connect();
        rs = stmt.executeQuery(query);

        //STEP 5: Extract data from result set
        while (rs.next()) {
            //Retrieve by column name
            result = rs.getString(column);
        }
        rs.close();
        closeConn();
        return result;
    }

    public void updateDB(String query) throws SQLException{
        connect();
        stmt.executeUpdate(query);
        //STEP 6: Clean-up environment
        closeConn();
    }

    public void closeConn() throws SQLException {
        stmt.close();
        conn.close();
    }

    public void finalBlock() {
        //finally block used to close resources
        try {
            if (stmt != null)
                stmt.close();
        } catch (SQLException se2) {
        }// nothing we can do
        try {
            if (conn != null)
                conn.close();
        } catch (SQLException se) {
            se.printStackTrace();
        }//end finally try
    }//end try
}
