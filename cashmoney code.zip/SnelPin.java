//package Gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class SnelPin {


	private static JFrame frmStartScherm;
	private static JLabel lblError;

	/**
	 * Launch the application.
	 */
	public static void window(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SnelPin window = new SnelPin();
					window.frmStartScherm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */

	public SnelPin() {
		initialize();
	}

	public static void getRid(){
		frmStartScherm.dispose();
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStartScherm = new JFrame();
		frmStartScherm.setTitle("snel \u20ac70");
		frmStartScherm.getContentPane().setBackground(Color.WHITE);
		frmStartScherm.setBounds(100, 100, 1318, 750);
		frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmStartScherm.getContentPane().setLayout(null);

		JLabel lblCashmoney = new JLabel("Wilt u snel \u20ac70?");
		lblCashmoney.setBounds(500, 43, 300, 50);
		lblCashmoney.setFont(new Font("Tahoma", Font.PLAIN,24));
		frmStartScherm.getContentPane().add(lblCashmoney);

		lblError = new JLabel("");
		lblError.setBounds(500, 190, 1100, 50);
		lblError.setFont(new Font("Tahoma", Font.PLAIN,24));
		frmStartScherm.getContentPane().add(lblError);

		JLabel lblA = new JLabel("A: Bevestig");
		lblA.setBounds(500, 75, 300, 50);
		lblA.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lblA);

		JLabel lblB = new JLabel("B: Terug naar keuzemenu");
		lblB.setBounds(500, 109, 300, 50);
		lblB.setFont(new Font("Tahoma", Font.PLAIN,24));
		frmStartScherm.getContentPane().add(lblB);

		JLabel lblD = new JLabel("D: Afbreken");
		lblD.setBounds(500, 143, 300, 50);
		lblD.setFont(new Font("Tahoma", Font.PLAIN,24));
		frmStartScherm.getContentPane().add(lblD);
	}
	public static void setLblError(String error){
		lblError.setText(error);
	}
}
