//package Gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class Bon {


    private static JFrame frmStartScherm;


    /**
     * Launch the application.
     */
    public static void window(){
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Bon window = new Bon();
                    window.frmStartScherm.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */

    public Bon() {
        initialize();
    }

    public static void getRid(){
        frmStartScherm.dispose();
    }


    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frmStartScherm = new JFrame();
        frmStartScherm.setTitle("Bon");
        frmStartScherm.getContentPane().setBackground(Color.WHITE);
        frmStartScherm.setBounds(100, 100, 1318, 750);
        frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frmStartScherm.getContentPane().setLayout(null);

        JLabel lblCashmoney = new JLabel("Bedankt voor het pinnen! Wilt u een bon?");
        lblCashmoney.setBounds(25, 64, 1192, 47);
        lblCashmoney.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lblCashmoney);

        JLabel lblA = new JLabel("A: Ja");
        lblA.setBounds(25, 84, 1192, 47);
        lblA.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lblA);

        JLabel lblB = new JLabel("B: Nee");
        lblB.setBounds(25, 104, 1192, 47);
        lblB.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lblB);
    }
}
