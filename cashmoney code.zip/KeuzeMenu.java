
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class KeuzeMenu {

	private static JFrame frmStartScherm;

	/**
	 * Launch the application.
	 */
	public static void window(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					KeuzeMenu window = new KeuzeMenu();
					window.frmStartScherm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */

	public KeuzeMenu() {initialize();}

	public static void getRid(){ frmStartScherm.dispose(); }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStartScherm = new JFrame();
		frmStartScherm.setTitle("Keuzemenu");
		frmStartScherm.getContentPane().setBackground(Color.WHITE);
		frmStartScherm.setBounds(100, 100, 1318, 750);
		frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmStartScherm.getContentPane().setLayout(null);

		JLabel txtCheckSaldo = new JLabel();
		txtCheckSaldo.setText("A: Check saldo");
		txtCheckSaldo.setBounds(500, 43, 300, 22);
		txtCheckSaldo.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(txtCheckSaldo);

		JLabel txtGeldOpnemen = new JLabel();
		txtGeldOpnemen.setText("B: Geld opnemen");
		txtGeldOpnemen.setBounds(500, 75, 300, 22);
		txtGeldOpnemen.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(txtGeldOpnemen);

		JLabel txtSnelEuro = new JLabel();
		txtSnelEuro.setText("C: Snel \u20ac70");
		txtSnelEuro.setBounds(500, 109, 300, 22);
		txtSnelEuro.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(txtSnelEuro);

		JLabel txtAfbreken = new JLabel();
		txtAfbreken.setText("D: Afbreken");
		txtAfbreken.setBounds(500, 143, 300, 22);
		txtAfbreken.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(txtAfbreken);
	}




}
