//package Gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class CheckSaldo {


	private static JFrame frmStartScherm;


	/**
	 * Launch the application.
	 */
	//public static void main(String[] args) {
	public static void window(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CheckSaldo window = new CheckSaldo();
					window.frmStartScherm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */

	public CheckSaldo() {
		initialize();
	}

	public static void getRid(){
		frmStartScherm.dispose();
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStartScherm = new JFrame();
		frmStartScherm.setTitle("Start scherm");
		frmStartScherm.getContentPane().setBackground(Color.WHITE);
		frmStartScherm.setBounds(100, 100, 1318, 750);
		frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmStartScherm.getContentPane().setLayout(null);

		JLabel lblSaldo = new JLabel("Uw saldo is: \u20ac"+DataRequest.getSaldo());
		lblSaldo.setBounds(500, 43, 300, 22);
		lblSaldo.setFont(new Font("Tahoma", Font.PLAIN, 30));
		frmStartScherm.getContentPane().add(lblSaldo);

		JLabel lblA = new JLabel("A: Geld opnemen");
		lblA.setBounds(25, 84, 1192, 47);
		lblA.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lblA);

		JLabel lblB = new JLabel("B: Terug naar keuzemenu");
		lblB.setBounds(25, 104, 1192, 47);
		lblB.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lblB);

		JLabel lblD = new JLabel("D: Afbreken");
		lblD.setBounds(25, 124, 1192, 47);
		lblD.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lblD);
	}
}
