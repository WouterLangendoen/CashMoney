//package Gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class PinCode {


    private static JFrame frmStartScherm;
    private static JPasswordField pinTxt;
    private static JLabel pinLbl;
    private static JLabel attemptsLbl;

    /**
     * Launch the application.
     */
    //public static void main(String[] args) {
    public static void window(){
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    PinCode window = new PinCode();
                    window.frmStartScherm.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */

    public PinCode() {
        initialize();
    }

    public static void getRid(){
        frmStartScherm.dispose();
    }


    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frmStartScherm = new JFrame();
        frmStartScherm.setTitle("Voer uw pincode in");
        frmStartScherm.getContentPane().setBackground(Color.WHITE);
        frmStartScherm.setBounds(100, 100, 1318, 750);
        frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frmStartScherm.getContentPane().setLayout(null);

        JLabel lblCheckEerstOf = new JLabel("Voer uw pincode in");
        lblCheckEerstOf.setBounds(500, 124, 1125, 50);
        lblCheckEerstOf.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lblCheckEerstOf);

        pinTxt = new JPasswordField();
        pinTxt.setBounds(500, 200, 100, 30);
        frmStartScherm.getContentPane().add(pinTxt);

        JLabel bevestig = new JLabel("Druk op A om te bevestigen");
        bevestig.setBounds(500, 250, 1125, 50);
        bevestig.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(bevestig);

        attemptsLbl = new JLabel("");
        attemptsLbl.setBounds(500, 340, 1125, 50);
        attemptsLbl.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(attemptsLbl);

        pinLbl = new JLabel("");
        pinLbl.setBounds(500, 400, 1125, 50);
        pinLbl.setFont(new Font("Tahoma", Font.PLAIN,24));
        frmStartScherm.getContentPane().add(pinLbl);

        JLabel lblClear = new JLabel("#: Correctie");
        lblClear.setBounds(500, 450, 300, 50);
        lblClear.setFont(new Font("Tahoma", Font.PLAIN,24));
        frmStartScherm.getContentPane().add(lblClear);

        JLabel lblD = new JLabel("D: Afbreken");
        lblD.setBounds(500, 500, 300, 50);
        lblD.setFont(new Font("Tahoma", Font.PLAIN,24));
        frmStartScherm.getContentPane().add(lblD);
    }

    public static void setPin(String digit){
        String curr = getPin();
        pinTxt.setText(curr+digit);
    }

    public static String getPin(){
        return pinTxt.getText();
    }

    public static void clearPin(){ pinTxt.setText("");}

    public static void setAttemptsLbl(int a){
        if(a<3) {
            attemptsLbl.setText("U heeft nog " + (3 - a) + " pogingen.");
        }
        else{
            attemptsLbl.setText("Uw pas is geblokkeerd");
        }
    }

    public static void setPinLbl(String p){
        pinLbl.setText(p);
    }
}
