

public class App {
    public static void main(String[] args) {

        ReadSerial rs = new ReadSerial();
        rs.initialize();
        rs.startWin();

    }

}