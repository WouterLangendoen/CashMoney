
import java.sql.*;

public class DataRequest{
    private static String pasnummer;
    private static int gepBedrag = 0;
    private static DBConnection connection = new DBConnection();

    public static void setPasnummer(String uid){
        pasnummer = uid;
    }
    public static String getPasnummer(){ return pasnummer; }
    public static int getGepBedrag(){ return gepBedrag; }

    public static String getReknr(){
        String reknr = "";
        try{
            reknr = connection.getData("SELECT Rekeningnummer FROM Bankpas WHERE Pasnummer = \""+pasnummer+"\" ", "Rekeningnummer");
        }
        catch (SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
            System.out.println("Connection failed");
        }
        finally{
            connection.finalBlock();
            return reknr;
        }
    }

    public static int getSaldo() {
        int saldo = 0;
        try {
            String saldoString = connection.getData("SELECT Saldo FROM Rekening, Bankpas  Where Pasnummer = \""+pasnummer+"\" AND Bankpas.Rekeningnummer = Rekening.Rekeningnummer;", "Saldo");
           saldo = Integer.parseInt(saldoString);
        }
        catch (SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
            System.out.println("Connection failed");
        }
        finally{
            connection.finalBlock();
        }
        return saldo;
    }

    public static boolean substract(int bedrag){
        boolean gepind = false;
        gepBedrag = bedrag;
       try {
            int saldo = getSaldo();
            int newSaldo = saldo - bedrag;
            int vandaagGep = Integer.parseInt(connection.getData("SELECT Vandaag_Gepind FROM Rekening, Bankpas  Where Pasnummer = \""+pasnummer+"\" AND Bankpas.Rekeningnummer = Rekening.Rekeningnummer;", "Vandaag_Gepind"));
           vandaagGep += gepBedrag;
           if(vandaagGep <= 500) {
               connection.updateDB("UPDATE Rekening, Bankpas SET Vandaag_Gepind = " + vandaagGep + " WHERE Pasnummer = \"" + pasnummer + "\" AND Bankpas.Rekeningnummer = Rekening.Rekeningnummer;");
               connection.updateDB("UPDATE Rekening, Bankpas SET Saldo = " + newSaldo + " WHERE Pasnummer = \"" + pasnummer + "\" AND Bankpas.Rekeningnummer = Rekening.Rekeningnummer;");
               gepind = true;
           }
           else{
               gepind = false;
           }
           vandaagGep = 0;
        }
        catch (SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
            System.out.println("Connection failed");
        }
        finally{
           connection.finalBlock();
        }
        return gepind;
    }
    public static void setWrongPinAttempts(boolean attempt){
        try {
            if (attempt == false) {
                connection.updateDB("UPDATE Bankpas SET Pin_Pogingen = 0 WHERE Pasnummer = \"" + pasnummer + "\" ;");
            } else {
                connection.updateDB("UPDATE Bankpas SET Pin_Pogingen = " + (getWrongPinAttempts() + 1) + " WHERE Pasnummer = \"" + pasnummer + "\";");
                if(getWrongPinAttempts() == 3){
                    connection.updateDB("UPDATE Bankpas SET Geblokkeerd = true WHERE Pasnummer = \"" + pasnummer + "\";");
                }
            }
        }
        catch (SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
            System.out.println("Connection failed");
        }
        finally{
            connection.finalBlock();
        }
    }

    public static int getWrongPinAttempts() {
        int wrongPinAttempts = 0;
        try {
            wrongPinAttempts = Integer.parseInt(connection.getData("SELECT Pin_Pogingen FROM Bankpas  Where Pasnummer = \"" + pasnummer + "\";", "Pin_Pogingen"));
        }
        catch (SQLException se){
            se.printStackTrace();
            System.out.println("Connection failed");
        }
        finally{
            connection.finalBlock();
        }
        return wrongPinAttempts;
    }

    public static boolean checkPin(String _pin){
        boolean pinCorrect = false;
        String pin = null;
        try {
             pin = connection.getData("SELECT Pasnummer FROM Bankpas Where Pincode = SHA1( \"" + _pin + "\");","Pasnummer" );
            if (pin.equals(pasnummer)) {
                System.out.println("pin correct");
                pinCorrect = true;
            } else {
                System.out.println("pin incorrect");
            }
        }
        catch (SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
            System.out.println("Connection failed");
        }
        catch (NullPointerException se){
            //Handle errors for JDBC
            se.printStackTrace();
            System.out.println("pin incorrect");
        }
        finally{
            connection.finalBlock();
        }
        return pinCorrect;
    }

    public static void clearData(){
        //pasnummer == null;
        System.out.println("Data cleared");
    }
}