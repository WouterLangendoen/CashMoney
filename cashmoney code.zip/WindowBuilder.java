//package Gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class WindowBuilder {

	
	private static JFrame frmStartScherm;
	

	/**
	 * Launch the application.
	 */
	public static void window(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WindowBuilder window = new WindowBuilder();
					window.frmStartScherm.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	public WindowBuilder() {
		initialize();
	}
		
	public static void getRid(){
		frmStartScherm.dispose();
	}
		

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmStartScherm = new JFrame();
		frmStartScherm.setTitle("Start scherm");
		frmStartScherm.getContentPane().setBackground(Color.WHITE);
		frmStartScherm.setBounds(100, 100, 1318, 750);
		frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frmStartScherm.getContentPane().setLayout(null);
		
		JLabel lblCashmoney = new JLabel("Hallo, welkom bij de bank CashMoney. Voordat u begint, willen wij u graag waarschuwen voor skimmers.");
		lblCashmoney.setBounds(25, 64, 1192, 50);
		lblCashmoney.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lblCashmoney);
		
		JLabel lblCheckEerstOf = new JLabel("Check eerst of er geen nep-scanner over de echte scanner zit.");
		lblCheckEerstOf.setBounds(25, 124, 1125, 50);
		lblCheckEerstOf.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lblCheckEerstOf);

		JLabel lbl2 = new JLabel(" Kijk altijd even goed om u heen of er geen mensen van een afstandje meekijken.");
		lbl2.setBounds(25, 333, 1125, 50);
		lbl2.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(lbl2);

		JLabel btnIkBegrijpHet = new JLabel("Druk op A om door te gaan");
		btnIkBegrijpHet.setBounds(431, 400, 338, 50);
		btnIkBegrijpHet.setFont(new Font("Tahoma", Font.PLAIN, 24));
		frmStartScherm.getContentPane().add(btnIkBegrijpHet);
	}
}
