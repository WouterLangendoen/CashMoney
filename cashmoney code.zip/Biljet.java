//package Gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.Window;

import javax.swing.JLabel;
import javax.swing.JSpinner;
import java.awt.Font;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Window.Type;

public class Biljet {


    private static JFrame frmStartScherm;
    private static JLabel lbl10;
    private static JLabel lbl20;
    private static JLabel lbl50;
    private static int aantal10 = 0;
    private static int aantal20 = 0;
    private static int aantal50 = 0;
    public static String arrow= " \u2190";
    public static String select10 = arrow;
    public static String select20 = "";
    public static String select50 = "";
    public static int bedragToPin = 0;
    private static int rest = 0;

    /**
     * Launch the application.
     */
    public static void window(){
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Biljet window = new Biljet();
                    window.frmStartScherm.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */

    public Biljet() {
        initialize();
    }

    public static void getRid(){
        frmStartScherm.dispose();
    }


    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frmStartScherm = new JFrame();
        frmStartScherm.setTitle("Biljetkeuze");
        frmStartScherm.getContentPane().setBackground(Color.WHITE);
        frmStartScherm.setBounds(100, 100, 1318, 750);
        frmStartScherm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frmStartScherm.getContentPane().setLayout(null);

        JLabel lblCheckEerstOf = new JLabel("Kies uw biljetten");
        lblCheckEerstOf.setBounds(500, 124, 1125, 50);
        lblCheckEerstOf.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lblCheckEerstOf);

        JLabel total = new JLabel("Nog \u20ac"+bedragToPin);
        total.setBounds(500, 340, 1125, 50);
        total.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(total);

        JLabel bevestig = new JLabel("Druk op A om te bevestigen");
        bevestig.setBounds(500, 370, 1125, 50);
        bevestig.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(bevestig);

        lbl10 = new JLabel("\u20ac10 x "+aantal10+select10);
        lbl10.setBounds(500, 250, 1125, 50);
        lbl10.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lbl10);

        lbl20 = new JLabel("\u20ac20 x "+aantal20+select20);
        lbl20.setBounds(500, 280, 1125, 50);
        lbl20.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lbl20);

        lbl50 = new JLabel("\u20ac50 x "+aantal50+select50);
        lbl50.setBounds(500, 310, 1125, 50);
        lbl50.setFont(new Font("Tahoma", Font.PLAIN, 24));
        frmStartScherm.getContentPane().add(lbl50);

        JLabel lblC = new JLabel("#: Correctie");
        lblC.setBounds(500, 430, 300, 50);
        lblC.setFont(new Font("Tahoma", Font.PLAIN,24));
        frmStartScherm.getContentPane().add(lblC);

        JLabel lblD = new JLabel("D: Afbreken");
        lblD.setBounds(500, 500, 300, 50);
        lblD.setFont(new Font("Tahoma", Font.PLAIN,24));
        frmStartScherm.getContentPane().add(lblD);
    }

    public static void setLbl(){
        lbl10.setText("\u20ac10 x "+aantal10+select10);
        lbl20.setText("\u20ac20 x "+aantal20+select20);
        lbl50.setText("\u20ac50 x "+aantal50+select50);
    }
}
