
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import gnu.io.CommPortIdentifier;
import gnu.io.SerialPort;
import gnu.io.SerialPortEvent;
import gnu.io.SerialPortEventListener;
import java.util.Enumeration;
import javax.swing.*;
import java.awt.*;

public class ReadSerial implements SerialPortEventListener {
    SerialPort serialPort;
    /**
     * The port we're normally going to use.
     */
    private static final String PORT_NAMES[] = {
            "/dev/tty.usbserial-A9007UX1", // Mac OS X
            "/dev/ttyACM0", // Raspberry Pi
            "/dev/ttyUSB0", // Linux
            "COM5", // Windows
    };
    /**
     * A BufferedReader which will be fed by a InputStreamReader
     * converting the bytes into characters
     * making the displayed results codepage independent
     */
    private BufferedReader input;
    /**
     * The output stream to the port
     */
    private OutputStream output;
    /**
     * Milliseconds to block while waiting for port open
     */
    private static final int TIME_OUT = 2000;
    /**
     * Default bits per second for COM port.
     */
    private static final int DATA_RATE = 9600;

    private String inputLine = "X";
    private String keyPress;


    public void initialize() {
        CommPortIdentifier portId = null;
        Enumeration portEnum = CommPortIdentifier.getPortIdentifiers();

        while (portEnum.hasMoreElements()) {
            CommPortIdentifier currPortId = (CommPortIdentifier) portEnum.nextElement();
            for (String portName : PORT_NAMES) {
                if (currPortId.getName().equals(portName)) {
                    portId = currPortId;
                    break;
                }
            }
        }
        if (portId == null) {
            System.out.println("Could not find COM port.");
            return;
        }

        try {
            // open serial port, and use class name for the appName.
            serialPort = (SerialPort) portId.open(this.getClass().getName(),
                    TIME_OUT);

            // set port parameters
            serialPort.setSerialPortParams(DATA_RATE,
                    SerialPort.DATABITS_8,
                    SerialPort.STOPBITS_1,
                    SerialPort.PARITY_NONE);

            // open the streams
            input = new BufferedReader(new InputStreamReader(serialPort.getInputStream()));
            output = serialPort.getOutputStream();

            // add event listeners
            serialPort.addEventListener(this);
            serialPort.notifyOnDataAvailable(true);
        } catch (Exception e) {
            System.err.println(e.toString());
        }
    }

    /**
     * This should be called when you stop using the port.
     * This will prevent port locking on platforms like Linux.
     */
    public synchronized void close() {
        if (serialPort != null) {
            serialPort.removeEventListener();
            serialPort.close();
        }
    }

    /**
     * Handle an event on the serial port. Read the data and print it.
     */
    public  void serialEvent(SerialPortEvent oEvent) {
        if (oEvent.getEventType() == SerialPortEvent.DATA_AVAILABLE) {
            try {
                inputLine = input.readLine();
                System.out.print(inputLine);
            } catch (Exception e) {
                //System.err.println(e.toString());
            }
        }
        // Ignore all the other eventTypes, but you should consider the other ones.
    }

    public void startWin(){
        WindowBuilder.window();
        boolean window = true;
        while(window == true){
            System.out.print(".");
            if (inputLine.equals("A")) {
                WindowBuilder.getRid();
                window = false;
                inputLine = "X";
                scanPasWin();
            }
        }
    }

    public void scanPasWin(){
        ScanPas.window();
        boolean window = true;
        while(window == true){
            System.out.print(".");
            if (inputLine.length() > 1){
                DataRequest.setPasnummer(inputLine);
                ScanPas.getRid();
                window = false;
                inputLine = "X";
                pinWin();
            }
            else if (inputLine.equals("D")){
                window = false;
                inputLine = "X";
                ScanPas.getRid();
                breekAf();
            }
        }
    }

    public void pinWin(){
        int i = 0;
        int p = 0;
        PinCode.window();
        PinCode.setAttemptsLbl(DataRequest.getWrongPinAttempts());
        boolean window = true;
        while(window == true){
            System.out.print(".");
            if (inputLine.equals("1")||inputLine.equals("2")||inputLine.equals("3")||inputLine.equals("4")||inputLine.equals("5")||inputLine.equals("6")||inputLine.equals("7")||inputLine.equals("8")||inputLine.equals("9")||inputLine.equals("0")){
                PinCode.setPin(inputLine);
                inputLine = "x";
            }
            else if (inputLine.equals("B")){
                if (i > 0) {
                    inputLine = "X";
                }
            }
            else if (inputLine.equals("#")){
                PinCode.clearPin();
            }

            else if (inputLine.equals("A") && (PinCode.getPin()).length() == 4) {
                PinCode.setAttemptsLbl(DataRequest.getWrongPinAttempts());
                if (DataRequest.getWrongPinAttempts()<3) {
                    if (DataRequest.checkPin(PinCode.getPin()) == true) {
                        DataRequest.setWrongPinAttempts(false);
                        PinCode.getRid();
                        window = false;
                        inputLine = "X";
                        keuzeWin();
                    } else {
                        PinCode.clearPin();
                        PinCode.setPinLbl("Pincode onjuist");
                        DataRequest.setWrongPinAttempts(true);
                        PinCode.setAttemptsLbl(DataRequest.getWrongPinAttempts());
                        inputLine = "X";
                    }
                }
            }
            else if (inputLine.equals("D")){
                window = false;
                inputLine = "X";
                PinCode.getRid();
                breekAf();
            }
        }
    }

    public void keuzeWin(){
        boolean window = true;
        KeuzeMenu.window();
        while(window == true){
            System.out.print(".");
            if (inputLine.equals("A")){
                window = false;
                inputLine = "X";
                KeuzeMenu.getRid();
                saldoWin();
            }
            else if (inputLine.equals("B")){
                window = false;
                inputLine = "X";
                KeuzeMenu.getRid();
                opneemWin();
            }
            else if (inputLine.equals("C")){
                window = false;
                inputLine = "X";
                KeuzeMenu.getRid();
                snelWin();
            }
            else if (inputLine.equals("D")){
                window = false;
                inputLine = "X";
                KeuzeMenu.getRid();
                breekAf();
            }
        }
    }

    public void saldoWin(){
        boolean window = true;
        CheckSaldo.window();
        while(window == true){
            System.out.print(".");
            if (inputLine.equals("A")){
                window = false;
                inputLine = "X";
                CheckSaldo.getRid();
                opneemWin();
            }
            else if (inputLine.equals("B")){
                window = false;
                inputLine = "X";
                CheckSaldo.getRid();
                keuzeWin();
            }
            else if (inputLine.equals("D")){
                window = false;
                inputLine = "X";
                CheckSaldo.getRid();
                breekAf();
            }
        }
    }

    public void opneemWin(){
        boolean window = true;
        int i = 0;
        GeldOpnemen.window();
        while(window == true){
            System.out.print(".");
            if (inputLine.equals("1")||inputLine.equals("2")||inputLine.equals("3")||inputLine.equals("4")||inputLine.equals("5")||inputLine.equals("6")||inputLine.equals("7")||inputLine.equals("8")||inputLine.equals("9")||inputLine.equals("0")){
                GeldOpnemen.setPinBedrag(inputLine);
                inputLine = "x";
                i++;
            }
            else if (inputLine.equals("A")){
                inputLine = "X";
                int pinBedrag = Integer.parseInt(GeldOpnemen.getPinBedrag());
                if (pinBedrag % 10 == 0) {
                    if(pinBedrag < DataRequest.getSaldo()) {
                        if(DataRequest.substract(pinBedrag)) {
                            GeldOpnemen.setLblError("");
                            window = false;
                            GeldOpnemen.getRid();
                            System.out.println("Geld opgenomen");
                            bonWin();
                        }
                        else{
                            GeldOpnemen.setLblError("U kunt maximaal \u20ac500 per dag pinnen");
                        }
                    }
                    else{
                        GeldOpnemen.setLblError("Saldo ontoereikend");
                    }
                }
                else{
                    GeldOpnemen.setLblError("Voer bedrag deelbaar door 10 in.");
                }
            }
            else if (inputLine.equals("B")){
                window = false;
                inputLine = "X";
                GeldOpnemen.getRid();
                keuzeWin();
            }
            else if (inputLine.equals("D")){
                window = false;
                inputLine = "X";
                GeldOpnemen.getRid();
                breekAf();
            }
        }
    }

    public void snelWin(){
        boolean window = true;
        SnelPin.window();
        while(window == true){
            System.out.print(".");
            if (inputLine.equals("A")){
                if(70 < DataRequest.getSaldo()) {
                    if(DataRequest.substract(70)) {
                        SnelPin.setLblError("");
                        window = false;
                        inputLine = "X";
                        SnelPin.getRid();
                        System.out.println("Geld opgenomen");
                        bonWin();
                    }
                    else{
                        SnelPin.setLblError("U kunt maximaal \u20ac500 per dag pinnen");
                    }
                }
                else{
                    SnelPin.setLblError("Saldo ontoereikend");
                }

            }
            else if (inputLine.equals("B")){
                window = false;
                inputLine = "X";
                SnelPin.getRid();
                keuzeWin();
            }
            else if (inputLine.equals("D")){
                window = false;
                inputLine = "X";
                SnelPin.getRid();
                breekAf();
            }
        }
    }

    public void bonWin(){
        boolean window = true;
        Bon.window();
        while(window == true) {
            System.out.print(".");
            if (inputLine.equals("A")) {
                window = false;
                inputLine = "X";
                Bon.getRid();
                PrintStil ps = new PrintStil();
                ps.print();
                breekAf();
            } else if (inputLine.equals("B")) {
                window = false;
                inputLine = "X";
                Bon.getRid();
                breekAf();
            }
        }
    }

    public void breekAf(){
        DataRequest.clearData();
        startWin();
    }
}